close all; clear all; clc;
filePath = 'dataset1_Mw.csv';

% Set the display format to long
format long;

% Increase the number of significant digits to 16
digits(16);
dataTable = readtable(filePath);
Ml = table2array(dataTable(1:end,4));

% Read the CSV file into a matrix
Lat = table2array(dataTable(1:end,1));
Lon = table2array(dataTable(1:end,2));
Dep = table2array(dataTable(1:end,3));
Ml = table2array(dataTable(1:end,4));
Mw = table2array(dataTable(1:end,5));
Mo = table2array(dataTable(1:end,6));
RA = table2array(dataTable(1:end,7));
RA_scaling = table2array(dataTable(1:end,8));

%% Unit Conversion by the BUILD-IN function
proj = projcrs(7855);
proj.GeographicCRS.Name;
[Lon_meter,Lat_meter] = projfwd(proj,Lat,Lon);
Dep = Dep*1000;

point = [-37.49,146.36,10];
[Point_Lon_meter,Point_Lat_meter] = projfwd(proj,point(1),point(2));

figure;
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
hold on;
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*100,'red','filled','hexagram');
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
set(gca,'ZDir','reverse');
hold on;
legend('Aftershock','Mainshock','Ml4.7 (SRC)','Ml4.2 (SRC)','Ml4.1 (GA)','Ml4.1 (SRC)');

%% Weighting point cloud
Mo_scaling = round(Mo/min(Mo)); 
% Mo_scaling = ones(length(Lat_meter),1); %every point is the same weight
% Mo_scaling(1) =1000; % give weight to mainshock 

Meter_matrix = [];
for i = 1:length(Mo_scaling)
    rows = Mo_scaling(i);
    add_ons = repmat([Lon_meter(i),Lat_meter(i),Dep(i)], rows, 1);
    Meter_matrix = [Meter_matrix;add_ons];
end

%% A*Lon (meter) + B*Lat (meter) + C = Dep (meter)
A_matrix = ones(length(Meter_matrix),3);
A_matrix(:,1) = Meter_matrix(:,1); % longitude
A_matrix(:,2) = Meter_matrix(:,2); % latitude
B_matrix = Meter_matrix(:,3); % depth

fprintf('\n');fprintf('<strong>A*x+B*y+C=Z / z = f(x,y)\n</strong>');
fit = inv(A_matrix'*A_matrix)*A_matrix'*B_matrix;
fit_meter = fit;
Plane_zaxis_angle(fit_meter); % calculate the strike and dip angle 

index = find(RA_scaling*100>=0.1);
% scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
% scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),5,'black','filled');
hold on;
% scatter3(Lon_meter(index(2:end)),Lat_meter(index(2:end)),Dep(index(2:end)),RA_scaling(index(2:end))*20000,'green','filled');
% scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*100,'red','filled');
axisLimits = axis;
[x, y] = meshgrid(axisLimits(1:2), axisLimits(3:4));
z = fit_meter(1)*x+fit_meter(2)*y+fit_meter(3);
surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b', 'FaceColor', 'y');
set(gca,'ZDir','reverse');
axis equal;
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
legend('Aftershock','Large-mag Aftershock','Mainshock','Fault Plane');
title('Depth = f(Longitude,Latitude)');
legend('Aftershock','Mainshock','Fault Plane');

% Residual calculation
plane_equation_coefficient = [fit_meter(1) fit_meter(2) -1 fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point,plane_equation_coefficient);
end
fprintf('\nNo weighted -- Residual (Sum of Distance): %.2f\n', sum(Distance(2:end)));

fprintf('Weighted -- Residual (Sum of Distance*weight): %.2f\n', sum(Distance.*Mo_scaling));

%% A*Lon (meter) + B*Dep (meter) + C = Lat (meter)
A_matrix = ones(length(Meter_matrix),3);
A_matrix(:,1) = Meter_matrix(:,1); % longitude
A_matrix(:,2) = Meter_matrix(:,3); % Depth
B_matrix = Meter_matrix(:,2); % latitude
figure;
fit = inv(A_matrix'*A_matrix)*A_matrix'*B_matrix;

fprintf('\n');fprintf('<strong>A*x+B*z+C=y / y = f(x,z)\n</strong>');
fit_meter = fit;
fit_revise = [fit_meter(1),-1,fit_meter(3)]./(-fit(2));
Plane_zaxis_angle(fit_revise);

index = find(RA_scaling*100>=0.1);
% scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
hold on;
% scatter3(Lon_meter(index(2:end)),Lat_meter(index(2:end)),Dep(index(2:end)),RA_scaling(index(2:end))*20000,'green','filled');
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*100,'red','filled');
axisLimits = axis;
[x, z] = meshgrid(axisLimits(1:2), axisLimits(5:6));
y = fit_meter(1)*x+fit_meter(2)*z+fit_meter(3);
% Plane_zaxis_angle(fit_meter);
surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b', 'FaceColor', 'y');
set(gca,'ZDir','reverse');
axis equal;
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
% legend('Aftershock','Large-mag Aftershock','Mainshock','Fault Plane');
legend('Aftershock','Mainshock','Fault Plane');
title('Latitude = f(Longitude,Depth)');


% Residual calculation
plane_equation_coefficient = [fit_meter(1) -1 fit_meter(2) fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point,plane_equation_coefficient);
end
fprintf('\nNo weighted -- Residual (Sum of Distance): %.2f\n', sum(Distance(2:end)));
fprintf('Weighted -- Residual (Sum of Distance*weight): %.2f\n', sum(Distance.*Mo_scaling));
%% A*Lat (meter) + B*Dep (meter) + C = Lon (meter)
figure;
A_matrix = ones(length(Meter_matrix),3);
A_matrix(:,1) = Meter_matrix(:,2); % Latitude
A_matrix(:,2) = Meter_matrix(:,3); % Depth
B_matrix = Meter_matrix(:,1); % Longitude

fit = inv(A_matrix'*A_matrix)*A_matrix'*B_matrix;
fprintf('\n');fprintf('<strong>A*y+B*z+C=x / x = f(y,z)\n</strong>');
fit_meter = fit;
fit_revise = [-1,fit_meter(1),fit_meter(3)]./(-fit(2));
[dip,strike] = Plane_zaxis_angle(fit_revise);
dip = abs(180-dip);

index = find(RA_scaling*100>=0.1);
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
% scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),5,'black','filled');
hold on;
% scatter3(Lon_meter(index(2:end)),Lat_meter(index(2:end)),Dep(index(2:end)),RA_scaling(index(2:end))*20000,'green','filled');
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*100,'red','filled');
axisLimits = axis;
[y, z] = meshgrid(axisLimits(3:4), axisLimits(5:6));
x = fit_meter(1)*y+fit_meter(2)*z+fit_meter(3);

% for identifying the rotate fault plane is align with expectation or not
plane_point = [x(1,1) y(1,1) z(1,1); x(1,2) y(1,2) z(1,2); x(2,1) y(2,1) z(2,1)];

surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b', 'FaceColor', 'y');
set(gca,'ZDir','reverse');
axis equal;
% set(gca,'xDir','reverse');
% set(gca,'YDir','reverse');
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
% legend('Aftershock','Large-mag Aftershock','Mainshock','Fault Plane');
legend('Aftershock','Mainshock','Fault Plane');
title('Longitude = f(Latitude,Depth)');


% Residual calculation
plane_equation_coefficient = [-1 fit_meter(1) fit_meter(2) fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point,plane_equation_coefficient);
end
index = find(Distance <= 50);
fprintf('\nNo weighted -- Residual (Sum of Distance): %.2f\n', sum(Distance(2:end)));

fprintf('Weighted -- Residual (Sum of Distance*weight): %.2f\n', sum(Distance.*Mo_scaling));


%% Histrogram Plotting -- exclude the mainshock Mo
Distance_plot = 0:250:max(Distance);
Mo_plot = zeros(length(Distance_plot),1);
for i = 1:length(Distance_plot)-1
    index_plot = find(Distance(2:end) >= Distance_plot(i) & Distance(2:end) < Distance_plot(i+1));
    Mo_plot(i) = sum(Mo(index_plot));
end


%% Strike and dip calculate
% Ax+By+Cz = D
function [theta_deg,angle_deg] = Plane_zaxis_angle(fit)
    a = fit(1);
    b = fit(2);
    if length(fit) == 4
        c = fit(3);
    else
        c = -1;
    end
    % Calculate the angle between the plane and the z-axis
    theta_rad = acos(c / sqrt(a^2 + b^2 + c^2));
    theta_deg = rad2deg(theta_rad);
    % Display the result
    fprintf('Angle between the plane and XY plane (dip）: %.2f degrees\n', abs(180-theta_deg));
    normal_vector = [a, b, c]; 
    % Y-axis vector
    x_axis = [1, 0, 0];
    % Calculate the dot product
    dot_product = dot(x_axis, normal_vector);
    % Calculate the angle in radians
    angle_rad = acos(dot_product / (norm(x_axis) * norm(normal_vector)));
    % Convert angle to degrees
    angle_deg = rad2deg(angle_rad);
    % Display the result
    fprintf('Angle between the plane and the YZ plane (strike): %.2f degrees\n', angle_deg);
end
