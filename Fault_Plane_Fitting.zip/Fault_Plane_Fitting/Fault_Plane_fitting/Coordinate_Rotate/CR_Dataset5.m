clear all;clc;close all;
filePath = 'dataset5_Mw.csv';

% Read the CSV file into a matrix
dataTable = readtable(filePath);
Lat = table2array(dataTable(1:end,1));
Lon = table2array(dataTable(1:end,2));
Dep = table2array(dataTable(1:end,3));
Ml = table2array(dataTable(1:end,4));
Mw = table2array(dataTable(1:end,5));
Mo = table2array(dataTable(1:end,6));
RA = table2array(dataTable(1:end,7));
RA_scaling = table2array(dataTable(1:end,8));
index = find(RA_scaling*100>=0.1);

% Unit Conversion by the BUILD-IN function
proj = projcrs(7855);
proj.GeographicCRS.Name;
[Lon_meter,Lat_meter] = projfwd(proj,Lat,Lon);
Dep = Dep*1000;

%% Give Weight to Matrix
Mo_scaling = round(Mo/min(Mo));
% Mo_scaling = ones(length(Lat_meter),1); %equal weight

Meter_matrix = [];
Meter_matrix_excel = [];
for i = 1:length(Mo_scaling)
    rows = Mo_scaling(i);
    %build-in function
    add_ons = repmat([Lon_meter(i),Lat_meter(i),Dep(i)], rows, 1);
    Meter_matrix = [Meter_matrix;add_ons];
end

%% Regression Line (find Strike)
[coefficients,lon_regression,lat_regression,angle_degrees,equation] = best_fit_line(Meter_matrix(:,1),Meter_matrix(:,2));
strike_coefficients = coefficients;
strike_equation = equation;

if angle_degrees < 0
    angle_degrees = 180+angle_degrees;
end
fprintf('Strike -- from build-in function conversion: %.2f degrees\n', angle_degrees);

scatter(Lon_meter(2:end),Lat_meter(2:end), RA_scaling(2:end)*40000,'black','filled');
% scatter(Lon_meter(2:end),Lat_meter(2:end),'black','filled');
hold on;
scatter(Lon_meter(index(2:end)),Lat_meter(index(2:end)), RA_scaling(index(2:end))*40000,'green','filled');
plot(lon_regression(:), lat_regression(:), 'k--','LineWidth',3);
scatter(Lon_meter(1),Lat_meter(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
grid on; axis equal;
ms_lon_meter = mean(Lon_meter(2:end)); ms_lat_meter = mean(Lat_meter(2:end));
hold on;
scatter(ms_lon_meter,ms_lat_meter,180,'filled','yellow','hexagram','MarkerEdgeColor', 'black')
% legend('Aftershock','Regression Line','Mainshock','Rotation Point');
legend('Aftershock','Large-Mag','Regression Line','Mainshock','Rotation Point');
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)'); 
title('Build-In Function Convertion');

[strike_coefficients,strike_lon_regression,strike_lat_regression,angle_degrees,strike_equation] = best_fit_line(Meter_matrix(:,1),Meter_matrix(:,2));
fprintf('Before Rotate -- Angle between regression line and y-axis (strike): %.2f degrees\n', angle_degrees);

rotate_lat = zeros(length(Lat),1);
rotate_lon = rotate_lat;

if angle_degrees<0 & abs(angle_degrees) <=90
    angle_degrees = abs(angle_degrees);
elseif angle_degrees>0 & abs(angle_degrees) <=90
    angle_degrees = -angle_degrees;
elseif  angle_degrees>0 & abs(angle_degrees) >90
    angle_degrees =angle_degrees-180;
end

angle_degrees = -angle_degrees;

%% Rotate the Coordinate based on the Medium point of AS cloud (origin point)
% Mainshock epicenter
% ms_lon_meter = Lon_meter(1); ms_lat_meter = Lat_meter(1);
% Medium point for AS cloud
ms_lon_meter = mean(Lon_meter(2:end)); ms_lat_meter = mean(Lat_meter(2:end));

rotation_angle_degrees = -angle_degrees; % calculate before
theta = deg2rad(rotation_angle_degrees); % 9 degrees rotation

for i = 1:length(Lat_meter)
    ox = Lon_meter(i) - ms_lon_meter;
    oy = Lat_meter(i) - ms_lat_meter;
    dx = ox*cos(theta) - oy*sin(theta);
    dy = ox*sin(theta) + oy*cos(theta);
    rotate_lon(i) =  ms_lon_meter + dx;
    rotate_lat(i) =  ms_lat_meter + dy;
end
figure;
subplot(2,1,1);
scatter(Lon_meter(2:end),Lat_meter(2:end), RA_scaling(2:end)*40000,'black','filled');
hold on;
scatter(Lon_meter(index(2:end)),Lat_meter(index(2:end)), RA_scaling(index(2:end))*40000,'green','filled');
hold on;
[coefficients,lon_regression,lat_regression,angle_degrees,equation] = best_fit_line(Meter_matrix(:,1),Meter_matrix(:,2));

plot(lon_regression(:), lat_regression(:), 'r--','LineWidth',3);
scatter(Lon_meter(1),Lat_meter(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
grid on; axis equal;
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)'); title('Original Coordinate');
legend('Aftershock','Regression Line','Mainshock');

subplot(2,1,2);
scatter(rotate_lon(2:end),rotate_lat(2:end),RA_scaling(2:end)*40000,'black','filled');

for i = 1:length(lon_regression)
    ox = lon_regression(i) - ms_lon_meter;
    oy = lat_regression(i) - ms_lat_meter;
    dx = ox*cos(theta) - oy*sin(theta);
    dy = ox*sin(theta) + oy*cos(theta);
    rotate_lon_regression(i) =  ms_lon_meter + dx;
    rotate_lat_regression(i) =  ms_lat_meter + dy;
end



hold on;
plot(rotate_lon_regression(:), rotate_lat_regression(:), 'r--','LineWidth',3);

% calculate the equation of rotated regression line
index_eq = find(rotate_lon_regression ~= rotate_lon_regression(1));
syms a b
aa = a*rotate_lon_regression(index_eq(1))+b == rotate_lat_regression(index_eq(1));
bb = a*rotate_lon_regression(1)+b == rotate_lat_regression(1);
eqns = [aa,bb];
S = solve(eqns,[a b]);
rotate_coefficient = [double(S.a),double(S.b)];

x = linspace (min(rotate_lon_regression),max(rotate_lon_regression));
y = rotate_coefficient(1)*x+rotate_coefficient(2);
plot(x,y,'b.','LineWidth',3);


scatter(rotate_lon(index(2:end)),rotate_lat(index(2:end)), RA_scaling(index(2:end))*40000,'green','filled');
scatter(rotate_lon(1),rotate_lat(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
axis equal; grid on;
ylabel('Strike (Meter)');xlabel('Parallel to Dip Direction (Meter)'); title('Rotated Coordinate');

figure;
%[coefficients,lon_regression,dep_regression] = regression_line(rotate_lon,Dep);
rotate_lon_weight = [];
for i = 1:length(Mo_scaling)
    rows = Mo_scaling(i);
    %build-in function
    add_ons = repmat([rotate_lon(i)], rows, 1);
    rotate_lon_weight = [rotate_lon_weight;add_ons];
end


[coefficients,dep_regression,lon_regression,angle_degrees,equation] = best_fit_line(Meter_matrix(:,3),rotate_lon_weight(:));
scatter(rotate_lon(2:end),Dep(2:end),10,'green','filled');
hold on;
plot(lon_regression(:),dep_regression(:),'r--','LineWidth',3);
scatter(rotate_lon(1),Dep(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
plot(lon_regression,dep_regression, 'r--','LineWidth',3);set(gca,'YDir','reverse');
axis equal; grid on;
legend('Aftershock','Regression Line','Mainshock')
ylabel('Dep (Meter)');xlabel('Parallel to Dip Direction (Meter)'); title('Rotated Coordinate');
fprintf('Rotated -- dip: %.2f degrees\n', angle_degrees);

%% calculating the sum of distance/ plot the plane -- find two line intersected point and project to the original coordinate

% surface regression line after rotation should be line parallel with y-axis
 x_mean = mean(rotate_lon_regression);
if equation == 1
    z_project = (x_mean-coefficients(2))/coefficients(1);
else
    z_project = x_mean*coefficients(1)+ coefficients(2);
end

y_mean = rotate_coefficient(1)*x_mean + rotate_coefficient(2);

dx = x_mean-ms_lon_meter;
dy = y_mean-ms_lat_meter;
syms ox oy
aa = dx == ox*cos(theta) - oy*sin(theta);
bb = dy == ox*sin(theta) + oy*cos(theta);
eqns = [aa,bb];
S = solve(eqns,[ox oy]);

x_project = double(S.ox)+ms_lon_meter;
y_project = double(S.oy)+ms_lat_meter;

% % calculate the plane equation
point = [x_project,y_project,z_project]; % the central point of AS cloud

syms A B C
index_min = find(lon_regression == min(lon_regression));
index_max = find(lon_regression == max(lon_regression));
aa = A*lon_regression(index_min) + B*lat_regression(index_min) + C == 0; % when project to the surface
bb = A*Lon_meter(1)+ B*Lat_meter(1) + C == Dep(1);
cc = A*point(1) + B*point(2)+ C == point(3);
eqns = [aa,bb,cc];
S = solve(eqns,[A B C]);
fit_meter = [double(S.A),double(S.B),double(S.C)];
Plane_zaxis_angle(fit_meter);

figure;
index = find(RA_scaling*100>=0.1);
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
hold on;
scatter3(Lon_meter(index(2:end)),Lat_meter(index(2:end)),Dep(index(2:end)),RA_scaling(index(2:end))*20000,'green','filled');
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*300,'red','filled');
axisLimits = axis;
[x, y] = meshgrid(axisLimits(1:2), axisLimits(3:4));
z = fit_meter(1)*x+fit_meter(2)*y+fit_meter(3);
surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b');
set(gca,'ZDir','reverse');
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Meter (Depth)')
axis equal;
zlim([min(Dep) max(Dep)]);
% Residual calculation %% A*Lon (meter) + B*Lat (meter) + C = Dep (meter)
plane_equation_coefficient = [fit_meter(1) fit_meter(2) -1 fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point1 = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point1,plane_equation_coefficient);
end
fprintf('\nNo-weight Residual (Sum of Distance): %.2f\n', sum(Distance(2:end)));

Mo_scaling = round(Mo/min(Mo));
fprintf('\nWeighted Residual (Sum of Distance): %.2f\n', sum(Distance.*Mo_scaling));

%% Residual (Distance of a point to the plane) -- test_passed
function Distance = distance_calculate(point,plane_equation_coefficient)
    up = abs(point(1)*plane_equation_coefficient(1)+point(2)*plane_equation_coefficient(2) ...
        +point(3)*plane_equation_coefficient(3)+plane_equation_coefficient(4));
    lower = sqrt(sum(power(plane_equation_coefficient(1:3),2)));
    Distance = up/lower;
end

%% finding the regression line which is best-fit for the point cloud (has the minimum sum of residuals)
function [coefficients,lon_regression,lat_regression,angle_degrees,x] = best_fit_line(lon,lat)
    [coefficients1,lon1,lat1] = linear_regresion(lon,lat);
    distance1 = 0;
    for i = 1:length(lat)
        distance1 = distance1 + abs(coefficients1(1)*lon(i)-lat(i)+coefficients1(2))/sqrt(power(coefficients1(1),2)+1);
    end
    [coefficients2,lat2,lon2] = linear_regresion(lat,lon);
    distance2 = 0;
    for i = 1:length(lat)
        distance2 = distance2 + abs(coefficients2(1)*lat(i)-lon(i)+coefficients2(2))/sqrt(power(coefficients2(1),2)+1);
    end
    
    if distance2 >= distance1
       coefficients = coefficients1;
       lat_regression = lat1;
       lon_regression = lon1;
        m = coefficients1(1);
        angle_degrees = atand(1/m);
        x = 1;
        fprintf('1 -- f(x)\n');
        % fprintf('Angle between regression line and y-axis: %.2f degrees\n', angle_degrees);
    else
        coefficients = coefficients2;
       lat_regression = lat2;
       lon_regression = lon2;
       m = coefficients2(1);
        angle_degrees = 90-atand(1/m);
        x = 2;
        fprintf('2 -- f(y)\n');
        % fprintf('Angle between regression line and y-axis: %.2f degrees\n', angle_degrees);
    end
end

%% 2D linear regression (different from the linear regression method for plane fitting which is 3D regression method)
function [coefficients,lon_regression,lat_regression] = linear_regresion(lon,lat)
coefficients = polyfit(lon, lat, 1);
lon_regression = linspace(min(lon), max(lon), 100);
lat_regression = polyval(coefficients, lon_regression);
end