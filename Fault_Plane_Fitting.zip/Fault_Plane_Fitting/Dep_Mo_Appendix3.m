clear all; close all; clc;

binLimits = [0,21]; % the max. depth in dataset 5 is 21 km, and the min. depth is 1.6 km.
binWidth = 0.5; % 0.5 km interval
BinEdges = binLimits(1):binWidth:binLimits(2);

figure;
subplot(2,1,1);
filePath = 'dataset5_Mw.csv';
dataTable = readtable(filePath);
Mo_count_withMS = dep_Mo_count(dataTable,binLimits,binWidth,BinEdges);
Mo_count_withoutMS = dep_Mo_count(dataTable(2:end,:),binLimits,binWidth,BinEdges);
ms_index = find(Mo_count_withMS(:,2)~=Mo_count_withoutMS(:,2));
bar(BinEdges(1:end-1)+binWidth/2,Mo_count_withoutMS(1:end-1,2));
axislimit = axis;
xlim([0 axislimit(2)]);
grid on;
hold on;
xlabel('Depth(KM)');
ylabel('Cumulative Mo per bin');
title('Energy Released');

subplot(2,1,2);
Dep = table2array(dataTable(:,3));
a = histogram(Dep, 'BinWidth', binWidth, 'BinLimits', binLimits);

count = a.Values;
bar(BinEdges(1:end-1)+binWidth/2,count);
xlabel('Depth(KM)');
ylabel('Number of Events per bin');
title('Frequency');
grid on;
axislimit = axis;
xlim([0 axislimit(2)]);



%% Function
function Mo_count = dep_Mo_count(dataTable,binLimits,binWidth,BinEdges)
    Dep = table2array(dataTable(:,3));
    Mo = table2array(dataTable(:,6));
    Mo_count = zeros(length(BinEdges),3);
    for i = 1:length(BinEdges)
        floor = binLimits(1) + (i-1)*binWidth;
        ceil = binLimits(1) + i*binWidth;
        Mo_count_middle = 0;
        Eq_count = 0;
        for j = 1:length(Dep)
            if Dep(j) >= floor && Dep(j) < ceil
                Mo_count_middle = Mo_count_middle + Mo(j);
                Eq_count = Eq_count+1;
            end
        end
        Mo_count(i,2) = Mo_count_middle;
        Mo_count(i,3) = Eq_count;
    end
    
    if length(Dep) == sum(Mo_count(:,3)) % check whether we miss some events
        disp('Length Check pass!');
    else
        disp('Check it again');
    end
    Mo_count(:,1) = BinEdges';
end
