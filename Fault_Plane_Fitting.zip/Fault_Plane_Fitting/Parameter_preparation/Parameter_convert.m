clear all;close all;clc;
Catalog = readtable('WP_20k_MS_20240807.csv');

latitude = table2array(Catalog(:,5));
longitude = table2array(Catalog(:,6));
% latitude_meter = table2array(Catalog(:,9));
% longitude_meter = table2array(Catalog(:,10));

dep = table2array(Catalog(:,7));
ml = table2array(Catalog(:,8));

entire_area = power(50*1000,2)*pi;

%% select the spatial range, if not specific selection, just run it without change
% Range 1 

% lon_range2 = [146.38 146.42];
% lat_range2 = [-37.47 -37.54];


% Range 2
% lon_range2 = [146.35 146.44];
% lat_range2 = [-37.45 -37.55];

% Range 3
lon_range2 = [min(longitude) max(longitude)];
lat_range2 = [min(latitude) max(latitude)];

validindex_lon = find(max(lon_range2) >= longitude & longitude >= min(lon_range2)); %lon
validindex_lat = find(max(lat_range2) >= latitude(:) & latitude(:) >= min(lat_range2)); %lat

validindex = intersect(validindex_lat,validindex_lon);

figure; % show the filter bundary
scatter(longitude,latitude,'filled','black');
hold on;
scatter(longitude(validindex),latitude(validindex),'filled','blue');
grid on;
scatter(longitude(1),latitude(1),'filled','red');
legend('Filtered','Keep','Mainshock');
title('In GPS Coordinate');

%% calculation for the remaining points
latitude = latitude(validindex);
longitude = longitude(validindex);
depth = dep(validindex);
Ml = ml(validindex);

%% Convert Ml to Mw
Mw = zeros(2,1);
for i = 1:length(Ml)
    Mw(i) = Ml2Mw(Ml(i));
end

%% I manually set the Mw of mainshock is 5.9 (woods point earthquake), because the Mw calculated from the equation above is lower than the published Mw.
Mw(1) = 5.9;

%% Mw to Seismic Moment 
Mo = power(10,3/2.*(Mw+10.7));
Mo_scaling = round(Mo/min(Mo));
%Rupture Area
RA = power(10,Mw-4.25);
RA_scaling = RA/max(RA); 

% write_matrix = [latitude,longitude,depth,Ml,Mw,Mo,RA,RA_scaling,latitude_meter,longitude_meter];
write_matrix = [latitude,longitude,depth,Ml,Mw,Mo,RA,RA_scaling];
sortedMatrix = sortrows(write_matrix, 5, 'descend');
%% write the file
filename = 'dataset6_August.csv';
writematrix(sortedMatrix, filename);
