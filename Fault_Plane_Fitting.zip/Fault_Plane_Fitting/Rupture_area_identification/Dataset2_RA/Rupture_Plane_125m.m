close all;
% rotate the coordiantes twice
% first rotation: based on the centriod of AS seqeunce (surface)
% Second rotation: based on the [dip_direction,strike] of MS (vertical)
%% Load dataset
close all; clear all; clc;
filePath = 'dataset2_Mw.csv';
load('Dataset2Mw_final.mat');
strike = -350.85; % value obtained from the final fit plane
dip = -(90-83.2); % value obtained from the final fit plane


damage_zone = 250;
bin_length = 200;
distance_limit = 10000; %10Km each side


fit_revise = fit_meter;
%filePath = 'WP_30days_range2_meter.csv';
% Set the display format to long
format long;

% Increase the number of significant digits to 16
digits(16);

% Read the CSV file into a matrix
dataTable = readtable(filePath);
Lat = table2array(dataTable(1:end,1));
Lon = table2array(dataTable(1:end,2));
% index = find(Lon >= 140 & Lon <= 149);
Dep = table2array(dataTable(1:end,3));
Ml = table2array(dataTable(1:end,4));
Mw = table2array(dataTable(1:end,5));
Mo = table2array(dataTable(1:end,6));
RA = table2array(dataTable(1:end,7));
% percentage = RA/sum(RA);
RA_scaling = table2array(dataTable(1:end,8));
proj = projcrs(7855);
proj.GeographicCRS.Name;
[Lon_meter,Lat_meter] = projfwd(proj,Lat,Lon);
Dep = Dep*1000;

plane_equation_coefficient = [fit_meter(1) fit_meter(2) -1 fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point,plane_equation_coefficient);
end

%% Find the original plane
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),5,'black','filled');
hold on;
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*100,'red','filled');
axisLimits = axis;
[x, y] = meshgrid(axisLimits(1:2), axisLimits(3:4));
z = fit_meter(1)*x+fit_meter(2)*y+fit_meter(3);
surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b', 'FaceColor', 'y');
set(gca,'ZDir','reverse');
axis equal;
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
legend('Aftershock','Large-mag Aftershock','Mainshock','Fault Plane');
title('Depth = f(Longitude,Latitude)');
legend('Aftershock','Mainshock','Fault Plane');
plane_point = [x(1,1) y(1,1) z(1,1); x(1,2) y(1,2) z(1,2); x(2,1) y(2,1) z(2,1)];

%% Find the rupture plane
% MS_RA = power(10, 2/3*log10(Mo(1))-14.95);
MS_RA = RA(1);
digitsOld = digits(100);
figure;
index = find(Distance <= damage_zone/2);
% the centroid of the point cloud
ms_lon_meter = mean(Lon_meter(2:end));
ms_lat_meter = mean(Lat_meter(2:end));
xlabel('Longitude'); ylabel('Latitude');zlabel('Depth')
title 'Before Rotation (first time)'
theta = -strike*pi/180;
beta = dip*pi/180;
%% Rotate -- fixed depth
% rotate the point cloud based on the centriod of AS
for i = 1:length(Lon_meter)
    ox = Lon_meter((i)) - ms_lon_meter;
    oy = Lat_meter((i)) - ms_lat_meter;
    dx = ox*cos(theta) - oy*sin(theta);
    dy = ox*sin(theta) + oy*cos(theta);
    Parallel_dip(i) =  ms_lon_meter + dx; % rotated_x
    Strike(i) =  ms_lat_meter + dy; % rotated_y
end

%% Rotate -- fixed Strike (obtained from the previous step)  -- second rotation
ms_x_rotate = Parallel_dip(1); % MS location
ms_y_rotate = Strike(1); % MS location
% ms_dep_meter = min(Dep(index)); 
ms_dep_meter = 0;

for i = 1:length(Dep)
    oz = Dep(i) - ms_dep_meter;
    ox = Parallel_dip(i) - ms_x_rotate;    
    dz = oz*cos(beta) - ox*sin(beta);
    dx = oz*sin(beta) + ox*cos(beta);
    Down_dip(i) =  ms_dep_meter + dz;
    Parallel_dip_2(i) =  ms_x_rotate + dx;
end


scatter(Lon_meter(index),Lat_meter(index),'filled');
hold on;
scatter(Lon_meter(1),Lat_meter(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
axis equal;

scatter(Parallel_dip(index(:)),Strike(index(:)),'filled');
hold on;
scatter(Parallel_dip(1),Strike(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
axis equal;
set(gca,'ZDir','reverse')
legend('before','before','after','after');
xlabel('Dip Direction(m)'); ylabel('Strike(m)');
title 'After Rotation (first time)'

figure;
scatter3(Parallel_dip_2(index(:)),Strike(index(:)),Down_dip(index(:)),'filled');
hold on;
scatter3(Parallel_dip_2(1),Strike(1),Down_dip(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
set(gca,'ZDir','reverse');
axis equal;
xlabel('Perpendicular to down-dip RA(m)'); ylabel('Strike(m)');zlabel('Down-Dip RA(m)');
title 'After Rotation (twice)'



figure;
scatter(Parallel_dip(index),Dep(index),'filled');
hold on;
scatter(Parallel_dip(1),Dep(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
scatter(Parallel_dip(index(:)),Down_dip(index(:)),'filled');
hold on;
axis equal;
scatter(Parallel_dip(1),Down_dip(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
set(gca,'YDir','reverse');
xlabel('Dip Direction(m)'); ylabel('Depth(m)');
title 'After Rotation (second time)'
legend('before','before','after','after');


mo_concentration = Mo(index(:));
%% find the area with max sum of Mo
% MS_RA = power(10, 2/3*log10(Mo(1))-14.95);
% Fault_width = MS_RA*1000*1000/Fault_length;
rake = 0; % assuming the rake angle == 0 degree
interval_strike = 100;
interval_dip = 100;
fault_length = min(Strike(index)):interval_strike:(max(Strike(index)));
fault_width = min(Down_dip(index)):interval_dip:(max(Down_dip(index)));
point_strike = 0;
point_dip = 0;
RA_Length = 0;
RA_Width = 0;
sum_mo = 0;
for i = 1:length(fault_length)
    for j = 1:length(fault_width)
        for Length = 0:100:(max(Strike(index))-min(Strike(index)))
            Width = MS_RA*1000*1000/Length;
            index_strike = find(Strike(index) >= fault_length(i) & Strike(index) < fault_length(i)+Length);
            index_dip = find(Down_dip(index) >= fault_width(j) & Down_dip(index) < fault_width(j)+Width);
            index_together = intersect(index_strike,index_dip);
            if sum(mo_concentration((index_together))) > sum_mo
                point_strike = fault_length(i);
                point_dip = fault_width(j);
                RA_Length = Length;
                RA_Width = Width;
                sum_mo = sum(mo_concentration((index_together)));
            end
        end
    end
end
figure; % Rupture Plane
% Define the vertices of the square
x = [point_strike point_strike+RA_Length point_strike+RA_Length point_strike]; % Strike
y = [point_dip point_dip point_dip+RA_Width point_dip+RA_Width]; % Down-dip
% Plot the square with filled color
fill(x, y, 'r','FaceAlpha',0.3); % 'r' denotes the color red
hold on;
scatter(Strike(index(2:end)),Down_dip(index(2:end)),RA_scaling(index(2:end))*30000,'filled');
scatter(Strike(1),Down_dip(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
axis equal;
set(gca,'YDir','reverse');
legend('Rupture Plane','On-fault Aftershocks','Mainshock');
xlabel('Strike(m)');ylabel('Down-dip Width(m)');
% title 'Damage Zone (250m)'
title 'Damage Zone (125m each side)'
grid on;
%% Find the Selected point used from distance_Mo curve
figure;
scatter3(Parallel_dip_2(index(:)),Strike(index(:)),Down_dip(index(:)),'filled');
hold on;
scatter3(Parallel_dip_2(1),Strike(1),Down_dip(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
ms_parallel_dip2 = ones(1,4)*Parallel_dip_2(1);
fill3(ms_parallel_dip2, x,y, 'r','FaceAlpha',0.3); % 'r' denotes the color red
axis equal;
legend('On-fault Aftershocks','Mainshock','Rupture Plane');
set(gca,'ZDir','reverse');
xlabel('Perpendicular to down-dip RA(m)'); ylabel('Strike(m)');zlabel('Down-Dip RA(m)');
title 'Rupture Plane (Rotated Coordinate)'

%% Rotate Back to xyz coordinate (Rupture) tRA_depth = y*cos(beta);
% x -- strike, y -- down-dip
for i = 1:length(y)
    syms a b  
    eq1 = y(i) ==  ms_dep_meter + (a - ms_dep_meter)*cos(beta) - (b - ms_x_rotate)*sin(beta);
    eq2 = Parallel_dip_2(1) ==  ms_x_rotate + (a - ms_dep_meter)*sin(beta) + (b - ms_x_rotate)*cos(beta);
    S = solve([eq1 eq2],[a b]);
    Dep_RA(i) = vpa(S.a); % the depth of RA
    Parallel_dip_RA(i) = vpa(S.b);
end
for i = 1:length(x)
    syms a b
    eq1 = Parallel_dip_RA(i) ==  ms_lon_meter + ((a - ms_lon_meter)*cos(theta) - (b - ms_lat_meter)*sin(theta));
    eq2 = x(i) ==  ms_lat_meter + ((a - ms_lon_meter)*sin(theta) + (b - ms_lat_meter)*cos(theta));
    S = solve([eq1 eq2],[a b]);
    Lon_meter_RA(i) = vpa(S.a);
    Lat_meter_RA(i) = vpa(S.b);
end
%% Rupture Area in Fault Plane
figure;

fprintf('Angle of Final Fit Plane\n');
Plane_zaxis_angle(fit_revise);

index = find(RA_scaling*100>=0.1);
scatter3(Lon_meter(2:end),Lat_meter(2:end),Dep(2:end),RA_scaling(2:end)*20000,'black','filled');
hold on;
scatter3(Lon_meter(index(2:end)),Lat_meter(index(2:end)),Dep(index(2:end)),RA_scaling(index(2:end))*20000,'green','filled');
scatter3(Lon_meter(1),Lat_meter(1),Dep(1),RA_scaling(1)*300,'red','filled');
axisLimits = axis;
[x, y] = meshgrid(axisLimits(1:2), axisLimits(3:4));
z = fit_meter(1)*x+fit_meter(2)*y+fit_meter(3);
surf(x, y, z, 'FaceAlpha', 0.9, 'EdgeColor', 'b', 'FaceColor', 'y');
fill3(Lon_meter_RA, Lat_meter_RA,Dep_RA, 'r','FaceAlpha',0.3); % 'r' denotes the color red
hold on;

set(gca,'ZDir','reverse');
axis equal;
xlabel('Meter (Longitude)');ylabel('Meter (Latitude)');zlabel('Depth');
legend('Aftershock','Large-mag Aftershock','Mainshock','Fault Plane (from Near-source region)','RA (calculated)');
title('x = f(y,z)');


for i = 1:length(Lon_meter_RA)
    point = [Lon_meter_RA(i) Lat_meter_RA(i) Dep_RA(i)];
    Distance_RA(i) = distance_calculate(point,plane_equation_coefficient);
end

%% Two planes angle
% the equation of RA
AB = [Lon_meter_RA(1)-Lon_meter_RA(2),Lat_meter_RA(1)-Lat_meter_RA(2),Dep_RA(1)-Dep_RA(2)];
AC = [Lon_meter_RA(1)-Lon_meter_RA(3),Lat_meter_RA(1)-Lat_meter_RA(3),Dep_RA(1)-Dep_RA(3)];
normal_vector = cross(AB,AC);

syms D
eq1 = normal_vector(1)*Lon_meter_RA(1)+normal_vector(2)*Lat_meter_RA(1)+normal_vector(3)*Dep_RA(1)+D == 0;
S = solve(eq1,D);
D = double(S);
fit_RA = [normal_vector,D];
fprintf('Angle of RA (In Earth Coordinate)\n');
Plane_zaxis_angle(fit_RA);

axisLimits = axis;
[x, y] = meshgrid(axisLimits(1:2), axisLimits(3:4));
z = double(-(normal_vector(1)*x+normal_vector(2)*y+D)/normal_vector(3));
disp('=== Rupture Area Info ===')
disp(['the length of the RA (m): ', num2str(round(RA_Length))])
disp(['the width of the RA (m): ', num2str(round(RA_Width))])
disp(['min. Dep of RA (m): ']);
disp(round(min(Dep_RA)));
disp(['max. Dep of RA (m): ']);
disp(round(max(Dep_RA)));

%% Energy Released
filePath = 'dataset6_August.csv';
dataTable = readtable(filePath);
Lat = table2array(dataTable(1:end,1));
Lon = table2array(dataTable(1:end,2));
Dep = table2array(dataTable(1:end,3));
Ml = table2array(dataTable(1:end,4));
Mw = table2array(dataTable(1:end,5));
Mo = table2array(dataTable(1:end,6));
RA = table2array(dataTable(1:end,7));
RA_scaling = table2array(dataTable(1:end,8));
proj = projcrs(7855);
proj.GeographicCRS.Name;
[Lon_meter,Lat_meter] = projfwd(proj,Lat,Lon);
Dep = Dep*1000;

plane_equation_coefficient = [fit_meter(1) fit_meter(2) -1 fit_meter(3)];
Distance = zeros(length(Lat_meter),1);
for i = 1:length(Lon_meter)
    point = [Lon_meter(i) Lat_meter(i) Dep(i)];
    Distance(i) = distance_calculate(point,plane_equation_coefficient);
end
for i = 1:length(Lon_meter)
    ox = Lon_meter((i)) - ms_lon_meter;
    oy = Lat_meter((i)) - ms_lat_meter;
    dx = ox*cos(theta) - oy*sin(theta);
    dy = ox*sin(theta) + oy*cos(theta);
    Parallel_dip(i) =  ms_lon_meter + dx; % rotated_x
    Strike(i) =  ms_lat_meter + dy; % rotated_y
end
ms_x_rotate = Parallel_dip(1); % MS location
ms_y_rotate = Strike(1); % MS location
ms_dep_meter = 0;

for i = 1:length(Dep)
    oz = Dep(i) - ms_dep_meter;
    ox = Parallel_dip(i) - ms_x_rotate;    
    dz = oz*cos(beta) - ox*sin(beta);
    dx = oz*sin(beta) + ox*cos(beta);
    Down_dip(i) =  ms_dep_meter + dz;
    Parallel_dip_2(i) =  ms_x_rotate + dx;
end
count = 1;
energy_release = zeros(2,3);
for i = 0:bin_length:distance_limit-bin_length
    index_dip_direction = find(Parallel_dip_2 <=Parallel_dip_2(1) + i +bin_length & Parallel_dip_2 >=Parallel_dip_2(1) - i -bin_length);
    index_strike_direction = find(Strike >= point_strike-i-bin_length & Strike < point_strike+RA_Length+i+bin_length);
    index_depth_direction = find(Down_dip >= point_dip-i-bin_length & Down_dip < point_dip+RA_Width+i+bin_length);
    index_together1 = intersect(index_dip_direction,index_strike_direction);
    index_together = intersect(index_together1,index_depth_direction);
    energy_release(count,:) = [i+bin_length,length(index_together),sum(Mo(index_together))];
    count = count+1;
end

energy_release(:,2) = energy_release(:,2)-1;
energy_release(:,3) = energy_release(:,3)-Mo(1);
energy_release = [[0,0,0];energy_release];

figure;
subplot(2,1,1);
plot(energy_release(:,1),energy_release(:,3)./max(energy_release(:,3))*100,'linewidth',1.2);
hold on;
plot(energy_release(:,1),energy_release(:,3)./max(energy_release(:,3))*100,'.');
xlabel('Distance From the Fault Plane (m)');
ylabel('Cumulative Mo Released (%)');
title 'Exclude Mainshock'
subplot(2,1,2);
for i = 1:length(energy_release)-1
    energy_difference(i) = (energy_release(i+1,3)-energy_release(i,3));
end
edges = [0:bin_length:energy_release(end,1)];
energy_difference_precentage = energy_difference/sum(Mo(2:end))*100;
histogram('BinEdges', edges, 'BinCounts', energy_difference_precentage);
xlim([0 distance_limit]);
xlabel('Distance From the Fault Plane (m)');
ylabel('Mo Released each bin (%)');
title 'Exclude Mainshock (bin 200m)'

% decrease the gap between the distance
distance_gap = 1;
energy_release1 = zeros(2,3);
count =1;
count_Mc = zeros(1,5); % calculate the amount of events >= ML .8
for i = 0:distance_gap:distance_limit-distance_gap
    index_dip_direction = find(Parallel_dip_2 <=Parallel_dip_2(1) + i +distance_gap & Parallel_dip_2 >=Parallel_dip_2(1) - i -distance_gap);
    index_strike_direction = find(Strike >= point_strike-i-distance_gap & Strike < point_strike+RA_Length+i+distance_gap);
    index_depth_direction = find(Down_dip >= point_dip-i-distance_gap & Down_dip < point_dip+RA_Width+i+distance_gap);

    index_together1 = intersect(index_dip_direction,index_strike_direction);
    index_together = intersect(index_together1,index_depth_direction);
    energy_release1(count,:) = [i+distance_gap,length(index_together),sum(Mo(index_together))]; 
    index_Mc = find(Ml >=0.8); count_Mc(1,count) = length(intersect(index_together,index_Mc));
    count = count+1;
end

energy_release1(:,2) = energy_release1(:,2)-1;
energy_release1(:,3) = energy_release1(:,3)-Mo(1);
energy_release1 = [[0,0,0];energy_release1];

index_90_Energy =find(energy_release1(:,3) >= 0.9*max(energy_release1(:,3)));
Energy_90_Distance = energy_release1(index_90_Energy(1),1); % The distance from AS to rupture plane, that energy released 90% of Total AS Mo

figure;
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1.5);
hold on;
plot(energy_release(:,1),energy_release(:,3)./max(energy_release(:,3))*100,'linewidth',1.5);
plot([Energy_90_Distance,Energy_90_Distance],[0 100],'k--','linewidth',1.5);
legend('1m bin','200m bin','90% Total Energy Released');

xlabel('Distance From the Fault Plane (m)');
ylabel('Cumulative Mo Released (%)');
title 'Exclude Mainshock'
grid on;

figure;
x = [point_strike point_strike+RA_Length point_strike+RA_Length point_strike]; % Strike
y = [point_dip point_dip point_dip+RA_Width point_dip+RA_Width]; % Down-dip
hold on;
scatter3(Parallel_dip_2(index_together),Strike(index_together),Down_dip(index_together),1,'filled','yellow');
scatter3(Parallel_dip_2(1),Strike(1),Down_dip(1),180,'filled','red','hexagram','MarkerEdgeColor', 'black');
scatter3(Parallel_dip_2(2),Strike(2),Down_dip(2),180,'filled','blue','hexagram','MarkerEdgeColor', 'black');
scatter3(Parallel_dip_2(3),Strike(3),Down_dip(3),180,'filled','green','hexagram','MarkerEdgeColor', 'black');

ms_parallel_dip2 = ones(1,4)*Parallel_dip_2(1);
fill3(ms_parallel_dip2, x,y, 'r','FaceAlpha',0.3); % 'r' denotes the color red
axis equal;
legend('Aftershocks','Mainshock','Ml4.7','Ml4.2','Rupture Plane');
set(gca,'ZDir','reverse');
xlabel('Perpendicular to down-dip RA'); ylabel('Strike');zlabel('Down-Dip RA');


%% distance between 2 points
distance1 = sqrt(power(Lon_meter_RA(1)-Lon_meter_RA(2),2)+ power(Lat_meter_RA(1)-Lat_meter_RA(2),2)+power(Dep_RA(1)-Dep_RA(2),2));
distance2 = sqrt(power(Lon_meter_RA(2)-Lon_meter_RA(3),2)+ power(Lat_meter_RA(2)-Lat_meter_RA(3),2)+power(Dep_RA(2)-Dep_RA(3),2));

%% Output files
RA_Earth_coordinate = [Lon_meter_RA',Lat_meter_RA',Dep_RA'];
RA_Info = [RA_Length,RA_Width];

save('RA_Earth_coordinate_DZ.mat', 'RA_Earth_coordinate');
save('RA_info_DZ.mat', 'RA_Info');
save('Dataset2_Energy_1_DZ_August.mat', 'energy_release1'); 

count_Mc = [[0],count_Mc];
save('Dataset2_Event_Frequency_1_DZ_August.mat', 'count_Mc'); 