%% Residual (Distance of a point to the plane) -- test_passed
function Distance = distance_calculate(point,plane_equation_coefficient)
    up = abs(point(1)*plane_equation_coefficient(1)+point(2)*plane_equation_coefficient(2) ...
        +point(3)*plane_equation_coefficient(3)+plane_equation_coefficient(4));
    lower = sqrt(sum(power(plane_equation_coefficient(1:3),2)));
    Distance = up/lower;
end