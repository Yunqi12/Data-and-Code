clear all;clc;close all;

%% WPAS until April 2024 (Seismic moment released)
%% Dataset 1
% subplot(2,1,1);
% load('Dataset1_Energy_1_DZ_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
% hold on;
% load('Dataset1_Energy_1_2km_April.mat')
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% %% Dataset 2
% load('Dataset2_Energy_1_DZ_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
% hold on;
% load('Dataset2_Energy_1_2km_April.mat')
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% %% Dataset 4
% load('Dataset4_Energy_1_DZ_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
% hold on;
% load('Dataset4_Energy_1_2km_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
% %% Dataset 5
% load('Dataset5_Energy_1_DZ_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
% hold on;
% load('Dataset5_Energy_1_2km_April.mat')
% for i = 2:length(energy_release1)
%     energy(i-1) = energy_release1(i,3)-energy_release1(i-1,3);
% end
% plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
% hold on;
% axislimit = axis;
% distance = 1500;
% x = [0 distance distance 0];
% y = [0 0 axislimit(end) axislimit(end)];
% fill(x, y, 'y','FaceAlpha',0.1); % 'r' denotes the color 
% 
% legend('D_1 Damge Zone','D_1 4Km','D_2 Damge Zone','D_2 4Km' ...
%       ,'D_4 Damge Zone','D_4 4Km','D_5 Damge Zone','D_5 4Km','On-fault Aftershock Zone');
% 
% xlabel('Distance From the Fault Plane (m)','FontSize',14);
% ylabel('Cumulative Mo Released (%)','FontSize',14);
% title('Since Mainshock to April (2024)','FontSize',14);
% grid on;

%% WPAS until August 2024
%% Dataset 1
subplot(2,1,1);
load('Dataset1_Energy_1_DZ_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
hold on;
load('Dataset1_Energy_1_2km_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--'); 

%% Dataset 2
load('Dataset2_Energy_1_DZ_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
hold on;
load('Dataset2_Energy_1_2km_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
%% Dataset 4
load('Dataset4_Energy_1_DZ_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
hold on;
load('Dataset4_Energy_1_2km_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
%% Dataset 5
load('Dataset5_Energy_1_DZ_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1);
hold on;
load('Dataset5_Energy_1_2km_August.mat')
index = find(energy_release1(:,1) == 1500);
plot(energy_release1(:,1),energy_release1(:,3)./max(energy_release1(:,3))*100,'linewidth',1,'LineStyle','--');
axislimit = axis;
distance = 1500;
x = [0 distance distance 0];
y = [0 0 axislimit(end) axislimit(end)];
fill(x, y, 'y','FaceAlpha',0.1); % 'r' denotes the color 

legend('D_1 Damge Zone','D_1 4Km','D_2 Damge Zone','D_2 4Km' ...
      ,'D_4 Damge Zone','D_4 4Km','D_5 Damge Zone','D_5 4Km','On-Fault Aftershock Zone');
xlabel('Distance From the Fault Plane (m)','FontSize',14);
ylabel('Cumulative Mo Released (%)','FontSize',14);
title('Seismic Moment','FontSize',14);
grid on;

%Frequency of events
subplot(2,1,2);
load('Dataset1_Event_Frequency_1_DZ_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1);
hold on;
load('Dataset1_Event_Frequency_1_2km_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1,'LineStyle','--'); 

%% Dataset 2
load('Dataset2_Event_Frequency_1_DZ_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1);
hold on;
load('Dataset2_Event_Frequency_1_2km_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1,'LineStyle','--'); 
%% Dataset 4
load('Dataset4_Event_Frequency_1_DZ_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1);
hold on;
load('Dataset4_Event_Frequency_1_2km_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1,'LineStyle','--'); 
%% Dataset 5
load('Dataset5_Event_Frequency_1_DZ_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1);
hold on;
load('Dataset5_Event_Frequency_1_2km_August.mat')
fprintf('Events in the Damage Zone occupied the total near-source events (%%): %f\n', round((count_Mc(1,1501)/max(count_Mc(1,:)) * 100),2));
plot(0:1:length(count_Mc)-1,count_Mc(1,:)./max(count_Mc(1,:))*100,'linewidth',1,'LineStyle','--'); 
axislimit = axis;
distance = 1500;
x = [0 distance distance 0];
y = [0 0 axislimit(end) axislimit(end)];
fill(x, y, 'y','FaceAlpha',0.1); % 'r' denotes the color 

legend('D_1 Damge Zone','D_1 4Km','D_2 Damge Zone','D_2 4Km' ...
      ,'D_4 Damge Zone','D_4 4Km','D_5 Damge Zone','D_5 4Km','On-Fault Aftershock Zone');
xlabel('Distance From the Fault Plane (m)','FontSize',14);
ylabel('Cumulative Events (%)','FontSize',14);
title('Event Frequency (ML >= 0.8)','FontSize',14);
grid on;